<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <link rel="stylesheet" href="/css/styles.css">
</head>
<body>
    <div class="header white">
        <p>Giant Book Supplier</p>
     </div>
     <nav>
         <ul>
             <li>
                 <a href="/">Home</a>
             </li>
             <li>
                <div class="dropdown">
                     <a href="#" class="drop-btn">Category</a>
                     <div class="dropdown-content">
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="/category-<?php echo e($c->id); ?>"><?php echo e($c->name); ?></a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
             </li>
             <li>
                 <a href="/publisher">Publisher</a>
             </li>
             <li>
                 <a href="/contact">Contact</a>
             </li>
         </ul>
     </nav>
     <?php echo $__env->yieldContent('content'); ?>
     <footer class="flex-center">&#169 Happy BookStore 2022</footer>
</body>
</html>
<?php /**PATH C:\Users\emanu\Documents\Kuliah\SEMESTER 5\UTS\GiantBookSupplier\resources\views/pageTemplate.blade.php ENDPATH**/ ?>