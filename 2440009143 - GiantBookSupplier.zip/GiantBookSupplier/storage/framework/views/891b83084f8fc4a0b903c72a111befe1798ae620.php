<?php $__env->startSection('title', 'Detail'); ?>

<?php $__env->startSection('content'); ?>
     <div class="bookDetail">
        <div class="bookList-header">Book Detail</div>
        <div class="book-detail">
            <img id="bookDetail-img" src="images/<?php echo e($book->image); ?>">
            <div class="bookDetail-info">
                <p class="bookTitle">Title : <?php echo e($book->title); ?></p>
                <p class="book-detail-info">Author : <?php echo e($book->author); ?></p>
                <p class="book-detail-info">Publisher : <?php echo e($book->name); ?></p>
                <p class="book-detail-info">Year : <?php echo e($book->year); ?></p>
                <p class="book-detail-info">Synopsis :</p>
                <p class="book-detail-info"><?php echo e($book->synopsis); ?></p>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('pageTemplate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\emanu\Documents\Kuliah\SEMESTER 5\UTS\GiantBookSupplier\resources\views/bookdetail.blade.php ENDPATH**/ ?>