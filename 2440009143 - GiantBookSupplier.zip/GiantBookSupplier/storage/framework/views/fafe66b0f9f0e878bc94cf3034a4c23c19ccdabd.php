<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <link rel="stylesheet" href="/css/styles.css">
</head>
<body>
    <div class="header white">
        <p>Giant Book Supplier</p>
     </div>
     <nav>
         <ul>
             <li>
                 <a href="#">Home</a>
             </li>
             <li>
                 <div class="dropdown">
                     <a class="drop-btn">Category
                     </a>
                     <div class="dropdown-content">
                     <a href="#">Category 1</a>
                     <a href="#">Category 2</a>
                     <a href="#">Category 3</a>
                     <a href="#">Category 4</a>
                     </div>
                 </div>
             </li>
             <li>
                 <a href="#">Publisher</a>
             </li>
             <li>
                 <a href="#">Contact</a>
             </li>
         </ul>
     </nav>
     <?php echo $__env->yieldContent('content'); ?>
     <footer class="flex-center">&#169 Happy BookStore 2022</footer>
</body>
</html>
<?php /**PATH C:\Users\emanu\Documents\Kuliah\SEMESTER 5\UTS\GiantBookSupplier\resources\views/navbar.blade.php ENDPATH**/ ?>