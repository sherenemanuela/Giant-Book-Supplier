<?php $__env->startSection('title', 'Contact'); ?>

<?php $__env->startSection('content'); ?>
     <div class="contact">
        <div class="bookList-header">Contact</div>
        <div class="contact-info">
            <p class="contact-title">Store address :</p>
            <p>Jalan Pembangunan Baru Raya,</p>
            <p>Kompleks Pertokoan Emerald Blok III/12</p>
            <p>Bintaro, Tangerang Selatan</p>
            <p>Indonesia</p>
            <p class="contact-title">Open Daily :</p>
            <p>08.00 - 20.00</p>
            <p class="contact-title">Contact :</p>
            <p>Phone : 021-08899776655</p>
            <p>Email : happybookstore@happy.com</p>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('pageTemplate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\emanu\Documents\Kuliah\SEMESTER 5\UTS\GiantBookSupplier\resources\views/contact.blade.php ENDPATH**/ ?>