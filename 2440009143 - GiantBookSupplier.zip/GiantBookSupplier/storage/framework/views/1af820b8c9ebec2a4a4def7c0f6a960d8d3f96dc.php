<?php $__env->startSection('title', 'Home'); ?>

<?php $__env->startSection('content'); ?>
    <div class="bookList">
        <div class="bookList-header">Book List</div>
        <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="book">
                <img src="images/<?php echo e($b->image); ?>">
                <div class="book-info">
                    <p class="bookTitle"><?php echo e($b->title); ?></p>
                    <p>by</p>
                    <p><?php echo e($b->author); ?></p>
                    <form action="/detail-<?php echo e($b->id); ?>" method="get">
                        <?php echo csrf_field(); ?>
                        <button class="detail-btn">Detail</button>
                    </form>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('pageTemplate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\emanu\Documents\Kuliah\SEMESTER 5\UTS\GiantBookSupplier\resources\views/home.blade.php ENDPATH**/ ?>