<?php

namespace App\Http\Controllers;

use App\Models\Books;

class HomeController extends Controller
{
    public function index(){
        $books = Books::all();
        return view('home', ['categories' => $this->categoryMenu(), 'books' => $books]);
    }
}
