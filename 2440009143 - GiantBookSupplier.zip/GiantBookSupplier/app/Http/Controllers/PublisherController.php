<?php

namespace App\Http\Controllers;

use App\Models\Books;
use App\Models\Publishers;

class PublisherController extends Controller
{
    public function index(){
        $books = Books::all();
        $publishers = Publishers::all();
        return view('publisher', ['categories' => $this->categoryMenu(),
                    'publishers' => $publishers,
                    'books' => $books]);
    }
}
