<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;

class BookDetailController extends Controller
{
    public function index($id){
        $book = DB::table('books')
                ->select('books.image', 'title', 'author', 'name', 'year', 'synopsis')
                ->join('publishers', 'books.publisher_id', '=', 'publishers.id')
                ->where('books.id', $id)
                ->get();
        return view('bookdetail', ['categories' => $this->categoryMenu(), 'book' => $book->first()]);
    }
}
