<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;

class CategoryController extends Controller
{
    public function index($cat_id){
        $books = DB::table('book_categories')
                    ->select('name', 'image', 'title', 'author', 'books.id')
                    ->join('books', 'book_categories.book_id', '=', 'books.id')
                    ->join('categories', 'categories.id', '=', 'book_categories.category_id')
                    ->where('categories.id', $cat_id)
                    ->get();
        return view('category', ['categories' => $this->categoryMenu(), 'books' => $books]);
    }
}
