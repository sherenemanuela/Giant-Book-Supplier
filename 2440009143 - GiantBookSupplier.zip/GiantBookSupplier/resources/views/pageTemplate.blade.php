<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>@yield('title')</title>
    <link rel="stylesheet" href="/css/styles.css">
</head>
<body>
    <div class="header white">
        <p>Giant Book Supplier</p>
     </div>
     <nav>
         <ul>
             <li>
                 <a href="/">Home</a>
             </li>
             <li>
                <div class="dropdown">
                     <a href="#" class="drop-btn">Category</a>
                     <div class="dropdown-content">
                    @foreach ($categories as $c)
                        <a href="/category-{{$c->id}}">{{ $c->name }}</a>
                    @endforeach
                    </div>
                </div>
             </li>
             <li>
                 <a href="/publisher">Publisher</a>
             </li>
             <li>
                 <a href="/contact">Contact</a>
             </li>
         </ul>
     </nav>
     @yield('content')
     <footer class="flex-center">&#169 Happy BookStore 2022</footer>
</body>
</html>
