@extends('pageTemplate')

@section('title', 'Detail')

@section('content')
     <div class="bookDetail">
        <div class="bookList-header">Book Detail</div>
        <div class="book-detail">
            <img id="bookDetail-img" src="images/{{$book->image}}">
            <div class="bookDetail-info">
                <p class="bookTitle">Title : {{$book->title}}</p>
                <p class="book-detail-info">Author : {{$book->author}}</p>
                <p class="book-detail-info">Publisher : {{$book->name}}</p>
                <p class="book-detail-info">Year : {{$book->year}}</p>
                <p class="book-detail-info">Synopsis :</p>
                <p class="book-detail-info">{{$book->synopsis}}</p>
            </div>
        </div>
    </div>
@endsection
