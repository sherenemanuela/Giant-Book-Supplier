@extends('pageTemplate')

@section('title', $books->first()->name)

@section('content')
    <div class="bookList">
        <div class="bookList-header">{{$books->first()->name}}</div>
        @foreach ($books as $b)
            <div class="book">
                <img src="images/{{$b->image}}">
                <div class="book-info">
                    <p class="bookTitle">{{$b->title}}</p>
                    <p>by</p>
                    <p>{{$b->author}}</p>
                    <form action="/detail-{{ $b->id }}" method="get">
                        @csrf
                        <button class="detail-btn">Detail</button>
                    </form>
                </div>
            </div>
        @endforeach
    </div>
@endsection
