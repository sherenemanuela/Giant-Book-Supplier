@extends('pageTemplate')

@section('title', 'Publisher')

@section('content')
    <div class="bookList">
        @foreach ($publishers as $p)
            <div class="publisher-header">
                <p>{{$p->name}}</p>
                <p>Address - {{$p->address}}</p>
                <p>Phone - {{$p->phone}}</p>
                <p>Email - {{$p->email}}</p>
            </div>
            @foreach ($books as $b)
                @if ($b->publisher_id == $p->id)
                    <div class="book">
                        <img src="images/{{$b->image}}">
                        <div class="book-info">
                            <p class="bookTitle">{{$b->title}}</p>
                            <p>by</p>
                            <p>{{$b->author}}</p>
                            <form action="/detail-{{ $b->id }}" method="get">
                                @csrf
                                <button class="detail-btn">Detail</button>
                            </form>
                        </div>
                    </div>
                @endif
            @endforeach
        @endforeach
    </div>
@endsection
