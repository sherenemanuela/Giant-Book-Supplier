<?php

namespace Database\Seeders;

use Carbon\Carbon;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class PublishersSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('publishers')->insert([[
            'name'=>'Gramedia',
            'address'=>'Jl. Palmerah Barat 29-37',
            'phone'=>'085277732711',
            'email'=>'gramedia@publisher.com',
            'image'=>'grasindo.jpg',
            'created_at'=>Carbon::now(),
            'updated_at'=>Carbon::now()
        ],
        [
            'name'=>'Deepublish',
            'address'=>'Jl. Rajawali Gg. Elang 6 No.3',
            'phone'=>'02742836082',
            'email'=>'deepublish@publisher.com',
            'image'=>'deepublish.jpg',
            'created_at'=>Carbon::now(),
            'updated_at'=>Carbon::now()
        ]
        ]);
    }
}
