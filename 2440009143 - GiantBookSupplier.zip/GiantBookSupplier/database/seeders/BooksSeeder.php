<?php

namespace Database\Seeders;

use Carbon\Carbon;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class BooksSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('books')->insert([[
            'publisher_id'=>1,
            'title'=>'The Lighthouse',
            'author'=>'Christopher Parker',
            'year'=>2022,
            'synopsis'=>'Something strange is happening in Seabrook.',
            'image'=>'thelighthouse.jpg',
            'created_at'=>Carbon::now(),
            'updated_at'=>Carbon::now()
        ],
        [
            'publisher_id'=>2,
            'title'=>'Hunger Games',
            'author'=>'Suzanne Collins',
            'year'=>2018,
            'synopsis'=>'In the ruins of a place once known as North America lies the nation of Panem, a shining Capitol surrounded by twelve outlying districts.',
            'image'=>'thehungergames.jpg',
            'created_at'=>Carbon::now(),
            'updated_at'=>Carbon::now()
        ],
        [
            'publisher_id'=>2,
            'title'=>'The Alchemist',
            'author'=>'Paulo Coelho',
            'year'=>2010,
            'synopsis'=>'Paulo Coelho\'s masterpiece tells the mystical story of Santiago, an Andalusian shepherd boy who yearns to travel in search of a worldly treasure.',
            'image'=>'thealchemist.jpg',
            'created_at'=>Carbon::now(),
            'updated_at'=>Carbon::now()
        ],
        [
            'publisher_id'=>1,
            'title'=>'Harry Potter',
            'author'=>'J.K. Rowling',
            'year'=>2002,
            'synopsis'=>'Ever since Harry Potter had come home for the summer, the Dursleys had been so mean and hideous that all Harry wanted was to get back to the Hogwarts School for Witchcraft and Wizardry.',
            'image'=>'harrypotter.jpg',
            'created_at'=>Carbon::now(),
            'updated_at'=>Carbon::now()
        ],
        [
            'publisher_id'=>1,
            'title'=>'Lavender House',
            'author'=>'Lev A.C. Rosen',
            'year'=>2022,
            'synopsis'=>'Lavender House, 1952: the family seat of recently deceased matriarch Irene Lamontaine, head of the famous Lamontaine soap empire. Irene\’s recipes for her signature scents are a well guarded secret—but it\'s not the only one behind these gates.',
            'image'=>'lavenderhouse.jpg',
            'created_at'=>Carbon::now(),
            'updated_at'=>Carbon::now()
        ],
        [
            'publisher_id'=>1,
            'title'=>'The Curator',
            'author'=>'Owen King',
            'year'=>2020,
            'synopsis'=>'It begins in an unnamed city nicknamed “the Fairest”, it is distinguished by many things but maybe especially so, by its essential unmappability.',
            'image'=>'thecurator.jpg',
            'created_at'=>Carbon::now(),
            'updated_at'=>Carbon::now()
        ],
        [
            'publisher_id'=>2,
            'title'=>'Hidden in Snow',
            'author'=>'Viveca Sten',
            'year'=>2020,
            'synopsis'=>'On the day Stockholm police officer Hanna Ahlander’s personal and professional lives crash, she takes refuge at her sister’s lodge in the Swedish ski resort paradise of Åre. But it’s a brief comfort.',
            'image'=>'hiddeninsnow.jpg',
            'created_at'=>Carbon::now(),
            'updated_at'=>Carbon::now()
        ],
        [
            'publisher_id'=>2,
            'title'=>'Bad Vibes Only',
            'author'=>'Nora McInerny',
            'year'=>2008,
            'synopsis'=>'Nora McInerny does not dance like no one is watching. In fact, she dances like everyone is watching, which is to say, she does not dance at all.',
            'image'=>'badvibesonly.jpg',
            'created_at'=>Carbon::now(),
            'updated_at'=>Carbon::now()
        ],
        [
            'publisher_id'=>1,
            'title'=>'Lute',
            'author'=>'Jennifer Marie Thorne',
            'year'=>2019,
            'synopsis'=>'On the idyllic island of Lute, every seventh summer, seven people die. No more, no less. Lute and its inhabitants are blessed, year after year, with good weather, good health, and good fortune.',
            'image'=>'lute.jpg',
            'created_at'=>Carbon::now(),
            'updated_at'=>Carbon::now()
        ]
        ]);
    }
}
